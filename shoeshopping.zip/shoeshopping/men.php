<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StepInStyle</title>
    <link rel="stylesheet" href="men.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>

    <div class="main">
        <div class="upper">
            <div class="name">
                <p>Welcome To StepInStyle</p>
            </div>
            <div class="dis">
                <marquee behavior="scroll" direction="left" onmouseover="stop()" onmouseout="start()">
                    <p>Get 5% Extra Discount On Prepaid Orders</p>
                </marquee>
            </div>
        </div>
        <div class="logo">
            <img src="Capture.png" alt="">
        </div>
        <div class="option">
            <ul>
                <span id="frst"><a href="men.php" style="color: black;"><li>Men</li></span></a>
                <span id="lines"><a href="women.php" style="color: black;"><li>Women</li></span></a>
                <span id="lines"><a href="kids.php" style="color: black;"><li>Kids</li></span></a>
                <span id="lines"><li>Brands</li></span>
                <span id="lines"><a href="sports.php" style="color: black;"><li>Sports</li></span></a>
                <span id="lines"><li>New</li></span>
                
            </ul>
        </div>

        <div class="srch">
            <div class="search-container">
                <input type="text" class="search-input" placeholder="Search..." aria-label="Search">
                <button class="search-button" aria-label="Perform search">
                    <svg class="search-icon" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#808080" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="11" cy="11" r="8"></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                </button>
            </div>

            <div class="home" id="hove">
                <a href="home.php" style="color: black;">
                    <i class="fa fa-home" style="font-size:30px; padding: 18px 10px 0px 22px;"></i>
                </a>
            </div>

            <div class="heart" id="hove">
            <a href="wishlist.php" style="color: black;" >
                <i class="fa fa-heart" style="font-size:29px; padding: 18px 10px 0px 22px;"></i></a>
            </div>

            <div class="cart" id="hove">
                <i class="fa fa-shopping-cart" style="font-size:30px; padding: 18px 10px 0px 22px;"></i>
            </div>
        </div>
    </div>
    <div class="men">
        <div class="pro1">
          <p align="center">Mens</p>
        </div>
        <div class="slider-container">
          <div class="slider" id="slider">
              <div class="product-card">
                  <img src="imgg1.png" alt="Product 1">
                  <h3>Product 1</h3>
                  <p>Short description of product 1.</p>
                  <div class="price">$49.99</div>
                  <button onclick="addToCart">Add to Cart</button>
                  <span class="wishlist-icon" onclick="addToWishlist(11, 'Air Glide', 'pic8.png', 119.99)">❤️</span>
              </div>
              <div class="product-card">
                  <img src="imgg2.png" alt="Product 2">
                  <h3>Product 2</h3>
                  <p>Short description of product 2.</p>
                  <div class="price">$59.99</div>
                  <button onclick="addToCart">Add to Cart</button>
                  <span class="wishlist-icon" onclick="addToWishlist(12, 'Air Glide', 'pic8.png', 119.99)">❤️</span>
              </div>
              <!-- Add more product cards up to 10 -->
              <div class="product-card">
                  <img src="imgg3.png" alt="Product 3">
                  <h3>Product 3</h3>
                  <p>Short description of product 3.</p>
                  <div class="price">$69.99</div>
                  <button onclick="addToCart">Add to Cart</button>
                  <span class="wishlist-icon" onclick="addToWishlist(13, 'Air Glide', 'pic8.png', 119.99)">❤️</span>
              </div>
              <div class="product-card">
                  <img src="imgg4.png" alt="Product 4">
                  <h3>Product 4</h3>
                  <p>Short description of product 4.</p>
                  <div class="price">$79.99</div>
                  <button onclick="addToCart()">Add to Cart</button>
                  <span class="wishlist-icon" onclick="addToWishlist(14, 'Air Glide', 'pic8.png', 119.99)">❤️</span>
              </div>
              <div class="product-card">
                  <img src="img8.png" alt="Product 5">
                  <h3>Product 5</h3>
                  <p>Short description of product 5.</p>
                  <div class="price">$89.99</div>
                  <button onclick="addToCart()">Add to Cart</button>
                  <span class="wishlist-icon" onclick="addToWishlist(15, 'Air Glide', 'pic8.png', 119.99)">❤️</span>
              </div>
              <div class="product-card">
                  <img src="imgg1.png" alt="Product 6">
                  <h3>Product 6</h3>
                  <p>Short description of product 6.</p>
                  <div class="price">$99.99</div>
                  <button onclick="addToCart()">Add to Cart</button>
                  <span class="wishlist-icon" onclick="addToWishlist(16, 'Air Glide', 'pic8.png', 119.99)">❤️</span>
              </div>
              <div class="product-card">
                  <img src="imgg2.png" alt="Product 7">
                  <h3>Product 7</h3>
                  <p>Short description of product 7.</p>
                  <div class="price">$109.99</div>
                  <button onclick="addToCart()">Add to Cart</button>
                  <span class="wishlist-icon" onclick="addToWishlist(16, 'Air Glide', 'pic8.png', 119.99)">❤️</span>
              </div>
              <div class="product-card">
                  <img src="imgg3.png" alt="Product 8">
                  <h3>Product 8</h3>
                  <p>Short description of product 8.</p>
                  <div class="price">$119.99</div>
                  <button onclick="addToCart()">Add to Cart</button>
                  <span class="wishlist-icon" onclick="addToWishlist(16, 'Air Glide', 'pic8.png', 119.99)">❤️</span>
              </div>
              <div class="product-card">
                  <img src="imgg4.png" alt="Product 9">
                  <h3>Product 9</h3>
                  <p>Short description of product 9.</p>
                  <div class="price">$129.99</div>
                  <button onclick="addToCart()">Add to Cart</button>
                  <span class="wishlist-icon" onclick="addToWishlist(16, 'Air Glide', 'pic8.png', 119.99)">❤️</span>
              </div>
              <div class="product-card">
                  <img src="img8.png" alt="Product 10">
                  <h3>Product 10</h3>
                  <p>Short description of product 10.</p>
                  <div class="price">$139.99</div>
                  <button onclick="addToCart()">Add to Cart</button>
                  <span class="wishlist-icon" onclick="addToWishlist(16, 'Air Glide', 'pic8.png', 119.99)">❤️</span>
              </div>
          </div>
</body>