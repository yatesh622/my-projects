<?php
session_start();
require 'db_connection.php';

if (isset($_POST['product_id'])) {
    $productId = $_POST['product_id'];
    $userId = $_SESSION['user_id'];

    // SQL query to delete the product from the wishlist
    $sql = "DELETE FROM wishlist WHERE product_id = '$productId' AND user_id = '$userId'";
    if (mysqli_query($conn, $sql)) {
        echo "Item removed successfully!";
        // Redirect back to wishlist page
        header('Location: wishlist.php'); // Replace 'wishlist_page.php' with the actual page displaying the wishlist
        exit;
    } else {
        echo "Error removing item: " . mysqli_error($conn);
    }
}
?>
