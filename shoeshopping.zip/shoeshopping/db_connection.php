<?php
// Database connection file

$servername = "localhost"; // Replace with your database server (e.g., 'localhost' if running locally)
$username = "root";        // Replace with your MySQL username
$password = "";            // Replace with your MySQL password
$dbname = "instylewebsite";  // Replace with your database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
// Connection is successful
?>
