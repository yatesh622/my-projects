<?php
session_start();

if (isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: profile.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StepInStyle</title>
    <link rel="stylesheet" href="profile.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style>
    button[name="logout"] {
        width: 71px;
        font-size: 14px;
        padding: 9px 10px;
        background-color: black; /* Red background */
        color: white; /* White text */
        border: none; /* Remove border */
        border-radius: 4px; /* Rounded corners */
        cursor: pointer; /* Pointer on hover */
        margin-top: 10px;
    }

    button[name="logout"]:hover {
        background-color: #d32f2f; /* Darker red on hover */
    }
</style>

<body>
    <div class="main">
        <div class="upper">
            <div class="name">
                <p>Welcome To StepInStyle</p>
            </div>
            <div class="dis">
                <marquee behavior="scroll" direction="left" onmouseover="stop()" onmouseout="start()">
                    <p>Get 5% Extra Discount On Prepaid Orders</p>
                </marquee>
            </div>
        </div>
        <div class="logo">
            <img src="Capture.png" alt="">
        </div>
        <div class="option">
            <ul>
                <span id="frst"><li>Men</li></span>
                <span id="lines"><li>Women</li></span>
                <span id="lines"><li>Kids</li></span>
                <span id="lines"><li>Brands</li></span>
                <span id="lines"><li>Sports</li></span>
                <span id="lines"><li>New</li></span>
            </ul>
        </div>

        <div class="srch">
            <div class="search-container">
                <input type="text" class="search-input" placeholder="Search..." aria-label="Search">
                <button class="search-button" aria-label="Perform search">
                    <svg class="search-icon" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#808080" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="11" cy="11" r="8"></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                </button>
            </div>

            <div class="home" id="hove">
                <a href="home.php" style="color: black;">
                    <i class="fa fa-home" style="font-size:30px; padding: 18px 10px 0px 22px;"></i>
                </a>
            </div>

            <div class="heart" id="hove">
                <i class="fa fa-heart" style="font-size:29px; padding: 18px 10px 0px 22px;"></i>
            </div>

            <div class="cart" id="hove">
                <i class="fa fa-shopping-cart" style="font-size:30px; padding: 18px 10px 0px 22px;"></i>
            </div>
        </div>
    </div>
    <div class="profile-container" align="center">
        <?php if (isset($_SESSION['username'])): ?>
            <!-- Display user details and logout button -->
            <h2>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>
            <form method="POST">
                <button type="submit" name="logout">Logout</button>
            </form>
        <?php else: ?>
            <h1>You are not logged in. Please <a href="#" onclick="openLoginModal()">login here</a>.</h1>
        <?php endif; ?>
    </div>
    <div class="contain">
        <!-- Login Modal -->
        <div id="loginModal" class="modal" style="display: none;">
            <div class="modal-content"><a href="home.php">
                <span class="close" onclick="closeLoginModal()">&times;</span></a>
                <h2>Login</h2><br><br>
                <form id="loginForm" method="POST" action="login.php">
                    <label for="email">Email:</label><br>
                    <input type="email" id="loginEmail" name="email" required><br>
                    <label for="password">Password:</label><br>
                    <input type="password" id="loginPassword" name="password" required><br><br>
                    <button type="submit">Login</button>
                </form>
                <br><br>
                <p>Don't have an account? <a href="#" onclick="openSignUpModal()">Sign up here</a></p>
            </div>
        </div>

        <!-- Sign-Up Modal -->
        <div id="signupModal" class="modal" style="display: none;">
            <div class="modal-content"><a href="home.php">
                <span class="close" onclick="closeSignUpModal()">&times;</span></a>
                <h2>Sign Up</h2><br><br>
                <form id="signupForm" method="POST" action="signup.php">
                    <label for="username">Username:</label><br>
                    <input type="text" id="signupUsername" name="username" required><br>
                    <label for="email">Email:</label><br>
                    <input type="email" id="signupEmail" name="email" required><br>
                    <label for="password">Create Password:</label><br>
                    <input type="password" id="signupPassword" name="password" required><br>
                    <label for="address">Address:</label><br>
                    <input type="text" id="signupAddress" name="address" required><br><br>
                    <button type="submit">Sign Up </button>
                </form>
            </div>
        </div>
    </div>

    <!-- JavaScript for Modal -->
    <script>
        // Open the Login Modal
        function openLoginModal() {
            document.getElementById('loginModal').style.display = 'flex';
        }

        // Close the Login Modal
        function closeLoginModal() {
            document.getElementById('loginModal').style.display = 'none';
        }

        // Open the Sign-Up Modal
        function openSignUpModal() {
            closeLoginModal();  // Close login modal if it's open
            document.getElementById('signupModal').style.display = 'flex';
        }

        // Close the Sign-Up Modal
        function closeSignUpModal() {
            document.getElementById('signupModal').style.display = 'none';
        }

        // Close the modals if clicked outside the modal content
        window.onclick = function(event) {
            if (event.target == document.getElementById('loginModal')) {
                closeLoginModal();
            }
            if (event.target == document.getElementById('signupModal')) {
                closeSignUpModal();
            }
        }
    </script>

</body>
</html>
