<?php
session_start();

// Check if user is logged in and if welcome popup has not been shown
if (isset($_SESSION['user_id']) && !isset($_SESSION['welcome_shown'])) {
    echo "<script>alert('Welcome " . $_SESSION['username'] . "!');</script>";
    
    // Set welcome_shown to true so the popup doesn't appear again
    $_SESSION['welcome_shown'] = true;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StepInStyle</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Latest compiled and minified CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Latest compiled JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>


<script>
        function showPopup() {
            var modal = document.getElementById("contactPopup");
            modal.style.display = "block";
        }

        function closePopup() {
            var modal = document.getElementById("contactPopup");
            modal.style.display = "none";
        }
    </script>

<style>
        #contactPopup {
            display: none;
            position: fixed;
            top: 20%;
            left: 30%;
            background-color: white;
            padding: 20px;
            border: 1px solid #ccc;
            z-index: 1000;
        }

        .slider-container {
            max-width: 1200px;
            overflow: hidden;
            position: relative;
            margin-top: 20px;
            margin-left: 60px;
        }

        .shop{
            height: 850px;
            width: 100%;
            float: left;
            /* background-color: lightcoral; */
        }

        .products{
            height: 1200px;
            width: 100%;
            float: left;
            /* background-color: black; */
        }

        .slidercontainer {
    width: 100%;
    max-width: 1251px; /* Optional: limit the width of the slider */
    overflow: hidden;
    position: relative;
    margin-top: 23px;
    padding-bottom: 40px;
}



.product-cardd {
    height: 475px;
    min-width: 250px;
    margin: 30px  10px;
    background-color: #fff;
    padding: 20px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    text-align: center;
    border-radius: 10px;
    flex: none;
    float: left;
}

.product-cardd img {
    width: 100%;
    border-radius: 10px;
}

.product-cardd h3 {
    font-size: 18px;
    margin: 10px 0;
}

.product-cardd p {
    color: #888;
    font-size: 16px;
    margin-bottom: 10px;
}

.product-cardd .price {
    font-size: 20px;
    color: #333;
    margin-bottom: 10px;
}

.product-cardd button {
    padding: 10px 15px;
    background-color: #ff7f50;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.product-cardd button:hover {
    background-color: #ff4500;
}
    </style>

</head>
<script>
        function addToCart() {
            <?php if (!isset($_SESSION['username'])): ?>
                alert("Please login first to add items to the cart.");
                window.location.href = 'profile.php'; // Redirect to login page
            <?php else: ?>
                // Proceed with add to cart action
                // AJAX call or form submission to add item to cart
                alert("Item added to cart successfully!");
            <?php endif; ?>
        }

        function addToWishlist() {
            <?php if (!isset($_SESSION['username'])): ?>
                alert("Please login first to add items to the wishlist.");
                window.location.href = 'profile.php'; // Redirect to login page
            <?php else: ?>
                // Proceed with add to wishlist action
                // AJAX call or form submission to add item to wishlist
                alert("Item added to wishlist successfully!");
            <?php endif; ?>
        }
    </script>
<body onload="<?php if ($showPopup) { echo 'showPopup()'; } ?>">

<!-- Contact Details Popup -->
<div id="contactPopup">
    <h2>Contact Details Submitted</h2>
    <p><strong>Name:</strong> <?php echo $_SESSION['name']; ?></p>
    <p><strong>Email:</strong> <?php echo $_SESSION['email']; ?></p>
    <p><strong>Message:</strong> <?php echo $_SESSION['message']; ?></p>
    <button onclick="closePopup()">Close</button>
</div>


      <div class="main">
            <div class="upper">
                <div class="name">
                    <p>Welcome To StepInStyle</p>
                </div>
                    <div class="dis">
                        <marquee behavior="scroll" direction="left" onmouseover="stop()" onmouseout="start()">
                            <p>Get 5% Extra Discount On Prepaid Orders</p></marquee>
                    </div>
            </div>
            <div class="logo">
                <img src="Capture.png" alt="">
            </div>
            <div class="option">
                <ul>
                    <span id="frst"><a href="men.php" style="color: black;"><li>Men</li></span></a>
                    <span id="lines"><a href="women.php" style="color: black;"><li>Women</li></span></a>
                    <span id="lines"><a href="kids.php" style="color: black;"><li>Kids</li></span></a>
                    <span id="lines"><li style="color: black;">Brands</li></span>
                    <span id="lines"><a href="sports.php" style="color: black;"><li>Sports</li></span></a>
                    <span id="lines"><li style="color: black;">New</li></span>
                    
                </ul>
            </div>
            <div class="srch">
              <div class="search-container">
                  <input type="text" class="search-input" placeholder="Search..." aria-label="Search">
                  <button class="search-button" aria-label="Perform search">
                      <svg class="search-icon" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#808080" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <circle cx="11" cy="11" r="8"></circle>
                          <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                      </svg>
                  </button>
              </div>
            
              <div class="profile" id="hove">
                <a href="profile.php" style="color: black;" >
                <i class="fa fa-user" style="font-size:30px; padding: 18px 10px 0px 22px;" >
                </i></a>
              </div>

              <div class="heart" id="hove">
                <a href="wishlist.php" style="color: black;">
                <i class="fa fa-heart" style="font-size:30px; padding: 18px 10px 0px 22px;">
                </i></a>
              </div>

              <div class="cart" id="hove">
              <a href="cart.php" style="color: black;">
                <i class="fa fa-shopping-cart" style="font-size:30px; padding: 18px 10px 0px 22px;">
                </i></a>
              </div>
            </div>
      
            <div class="image">
                <!-- Carousel -->
              <div id="demo" class="carousel slide" data-bs-ride="carousel">
        
            <!-- Indicators/dots -->
            <div class="carousel-indicators">
              <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
              <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
              <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
              <button type="button" data-bs-target="#demo" data-bs-slide-to="3"></button>

            </div>
          
            <!-- The slideshow/carousel -->
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src="img5'.png" alt="img1" class="d-block w-100 imgg">
              </div>
              <div class="carousel-item">
                <img src="https://hips.hearstapps.com/hmg-prod/images/cushioned-shoes-15407-1632754173.jpg" alt="img3" class="d-block w-100 imgg">
              </div>
              <div class="carousel-item">
                <img src="https://www.rei.com/dam/tuttle_03272022_0886_web_med.jpeg" alt="img3" class="d-block w-100 imgg">
              </div>
              <div class="carousel-item">
                <img src="https://media-cldnry.s-nbcnews.com/image/upload/t_nbcnews-fp-1024-512,f_auto,q_auto:best/rockcms/2024-03/240322-walking-shoes-bd-main-e6983e.jpg" alt="img5" class="d-block w-100 imgg">
              </div>
            </div>
          
            <!-- Left and right controls/icons -->
            <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
              <span class="carousel-control-prev-icon"></span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
              <span class="carousel-control-next-icon"></span>
            </button>
            </div>
            </div> 
            <div class="shop">
              <div class="shop1">
                <p>Shop For Every Movement</p>
              </div>
              <div class="shop2">
                <ul>
                  <li style="font-size: 60px;"><b><u>R</u>UNNING</b></li>
                  <li>WALKING</li>
                  <li>TRAINING</li>
                  <li>CLASSICS</li>
                </ul>
              </div>
              .
              <div class="slider-container">
                <div class="slider" id="slider">
                    <div class="product-card">
                        <img src="imgg1.png" alt="Product 1">
                        <h3>Urban Sneakers</h3>
                        <p>Lightweight and breathable running <br>
                        shoes perfect for urban adventures</p>
                        <div class="price">$49.99</div>
                        <button onclick="addToCart()">Add to Cart</button>
                        <span class="wishlist-icon" onclick="addToWishlist(1, 'Urban Sneakers', 'imgg1.png', 49.99)">❤️</span>

                    </div>
                    <div class="product-card">
                        <img src="imgg2.png" alt="Product 2">
                        <h3>Trail Blazer</h3>
                        <p>Durable trail running shoes<br> designed 
                        for tough terrains </p>
                        <div class="price">$59.99</div>
                        <button onclick="addToCart()">Add to Cart</button>
                        <span class="wishlist-icon" onclick="addToWishlist(2, 'Trail Blazer', 'imgg2.png', 59.99)">❤️</span>
                    </div>
                    <!-- Add more product cards up to 10 -->
                    <div class="product-card">
                        <img src="imgg3.png" alt="Product 3">
                        <h3>Comfy Kicks</h3>
                        <p>Casual sneakers with a soft <br>insole,perfect for all-day wear.</p>
                        <div class="price">$69.99</div>
                        <button onclick="addToCart()">Add to Cart</button>
                        <span class="wishlist-icon" onclick="addToWishlist(3, 'Comfy Kicks', 'imgg3.png', 69.99)">❤️</span>
                    </div>
                    <div class="product-card">
                        <img src="imgg4.png" alt="Product 4">
                        <h3>Speed Runner</h3>
                        <p>Lightweight racing shoes designed <br>
                            for ultimate speed and agility.</p>
                        <div class="price">$79.99</div>
                        <button onclick="addToCart()">Add to Cart</button>
                        <span class="wishlist-icon" onclick="addToWishlist(4, 'Speed Runner', 'imgg4.png', 79.99)">❤️</span>
                    </div>
                    <div class="product-card">
                        <img src="img8.png" alt="Product 5">
                        <br><br>
                        <h3>Luxury Leather</h3>
                        <p>Elegant leather shoes that combine <br>style and comfort for any occasion.</p>
                        <div class="price">$89.99</div>
                        <button onclick="addToCart()">Add to Cart</button>
                        <span class="wishlist-icon" onclick="addToWishlist(5, 'Luxury Leather', 'img8.png', 89.99)">❤️</span>
                    </div>
                                <div class="product-card">
                        <img src="img6.png" alt="Product 6"><br><br>
                        <h3>Flex Trainers</h3>
                        <p>Versatile training shoes ideal for <br>
                            both the gym and outdoor activities.</p>
                        <div class="price">$99.99</div>
                        <button onclick="addToCart()">Add to Cart</button>
                        <span class="wishlist-icon" onclick="addToWishlist(6, 'Flex Trainers', 'img6.png', 99.99)">❤️</span>
                    </div>
                    <div class="product-card">
                        <img src="img9.png" alt="Product 7">
                        <h3>Performance Pro</h3>
                        <p>High-performance shoes built for <br>athletes who demand excellence.</p>
                        <div class="price">$109.99</div>
                        <button onclick="addToCart()">Add to Cart</button>
                        <span class="wishlist-icon" onclick="addToWishlist(7, 'Performance Pro', 'img9.png', 109.99)">❤️</span>
                    </div>
                                <div class="product-card">
                        <img src="imagee8.png" alt="Product 8">
                        <h3>Cloud Comfort</h3>
                        <p>Ultra-cushioned shoes for  <br>maximum comfort during long walks.</p>
                        <div class="price">$119.99</div>
                        <button onclick="addToCart()">Add to Cart</button>
                        <span class="wishlist-icon" onclick="addToWishlist(8, 'Cloud Comfort', 'imagee6.png', 119.99)">❤️</span>
                    </div>
                    <div class="product-card">
                        <img src="imagee1.png" alt="Product 9">
                        <h3>Vintage Vibe</h3>
                        <p>Retro-inspired sneakers with a modern <br> twist, perfect for casual wear.</p>
                        <div class="price">$129.99</div>
                        <button onclick="addToCart()">Add to Cart</button>
                        <span class="wishlist-icon" onclick="addToWishlist(9, 'Vintage Vibe', 'imagee1.png', 129.99)">❤️</span>
                    </div>
                    <div class="product-card">
                        <img src="imagee2.png" alt="Product 10">
                        <h3>Elite Racer</h3>
                        <p>Top-tier racing shoes engineered for <br>
                             serious runners looking for speed.</p>
                        <div class="price">$139.99</div>
                        <button onclick="addToCart()">Add to Cart</button>
                        <span class="wishlist-icon" onclick="addToWishlist(10, 'Elite Racer', 'imagee2.png', 139.99)">❤️</span>
                    </div>
                    <div class="product-card">
                        <img src="imagee3.png" alt="Product 11">
                        <h3>Elite Racer</h3>
                        <p>Top-tier racing shoes engineered for <br>serious runners looking for speed.</p>
                        <div class="price">$139.99</div>
                        <button onclick="addToCart()">Add to Cart</button>
                        <span class="wishlist-icon" onclick="addToWishlist(10, 'Elite Racer', 'imagee2.png', 139.99)">❤️</span>
                    </div>
                    
        <div class="product-card">
                        <img src="imagee4.png" alt="Product 12">
                        <h3>Air Max Breeze</h3>
                        <p>Ultra-lightweight shoes with <br>  for comfortable run.</p>
                        <div class="price">$139.99</div>
                        <button onclick="addToCart()">Add to Cart</button>
                        <span class="wishlist-icon" onclick="addToWishlist(11, 'Air Max Breeze', 'imagee4.png', 139.99)">❤️</span>
                    </div>
                    <div class="product-card">
                        <img src="imagee5.png" alt="Product 13">
                        <h3>Stealth Runner</h3>
                        <p>Sleek and stylish running shoes <br><br>
                             for running and walking.</p>
                        <div class="price">$149.99</div>
                        <button onclick="addToCart()">Add to Cart</button>
                        <span class="wishlist-icon" onclick="addToWishlist(12, 'Stealth Runner', 'imagee5.png', 149.99)">❤️</span>
                    </div>
                    <div class="product-card">
                        <img src="imagee8.png" alt="Product 14">
                        <h3>Peak Performance</h3>
                        <p>built for extreme outdoor  <br>activities and endurance.</p>
                        <div class="price">$159.99</div>
                        <button onclick="addToCart()">Add to Cart</button>
                        <span class="wishlist-icon" onclick="addToWishlist(13, 'Peak Performance', 'imagee8.png', 159.99)">❤️</span>
                    </div>
                    <div class="product-card">
                        <img src="imagee7.png" alt="Product 15">
                        <h3>Eco Warrior</h3>
                        <p>Eco-friendly shoes perfect  <br>for conscious consumers.</p>
                        <div class="price">$169.99</div>
                        <button onclick="addToCart()">Add to Cart</button>
                        <span class="wishlist-icon" onclick="addToWishlist(14, 'Eco Warrior', 'imagee7.png', 169.99)">❤️</span>
                    </div>
                </div>
                <div class="slider-controls">
                    <button id="prev">&lt;</button>
                    <button id="next">&gt;</button>
                </div>
            </div>  
          </div>
</div>
          <div class="brand">
            <h3 align="center">Shop By Brands</h3>
            <div class="cont">
            <div class="cont1">
              <img src="https://fixationpk.com/storage/brands/8207301067-3e5834052a-w.jpg" alt="">
            </div>
            <div class="cont2">
              <img src="https://logowik.com/content/uploads/images/fila2021.logowik.com.webp" alt="">
            </div>
            <div class="cont3">
              <img src="https://pbs.twimg.com/profile_images/1088383035807096832/UCHk9AIP_400x400.jpg" alt="">
            </div>
            <div class="cont4">
              <img src="image1.png" alt="">
            </div>
            <div class="cont5">
              <img src="https://static.vecteezy.com/system/resources/previews/023/871/198/original/reebok-logo-brand-clothes-with-name-red-symbol-design-icon-abstract-illustration-free-vector.jpg" alt="">
            </div>
          </div>   
        </div> 
        <div class="shopsy">
          <div class="boxx1">
            <p>Shopping For?</p>
          </div>
          <div class="boxx2"><a href="men.php">
            <img src="Screenshot.png" alt=""></a>
          </div>
          <div class="boxx3"><a href="women.php">
            <img src="Screenshot 2.png" alt=""></a>
          </div>
        </div>
        <div class="products">
          <div class="pro1">
            <p>Recommended For You</p>
          </div>
          <div class="slidercontainer">
              <div class="product-cardd">
                  <img src="pic1.png" alt="Product 1">
                  <h3>Street Sprint</h3>
                    <p>Lightweight sneakers for <br> everyday comfort.</p>
                    <div class="price">$99.99</div>
                    <button onclick="addToCart()">Add to Cart</button>
                    <span class="wishlist-icon" onclick="addToWishlist(1, 'Street Sprint', 'pic1.png', 49.99)">❤️</span>
                </div>
              <div class="product-cardd">
                  <img src="pic2.png" alt="Product 2">
                  <h3>Terrain Trek</h3>
                    <p>Durable shoes for  <br>rugged outdoor paths.</p>
                    <div class="price">$59</div>
                    <button onclick="addToCart()">Add to Cart</button>
                    <span class="wishlist-icon" onclick="addToWishlist(2, 'Terrain Trek', 'pic2.png', 59.99)">❤️</span>
                </div>
              <!-- Add more product cards up to 10 -->
              <div class="product-cardd">
                  <img src="pic3.png" alt="Product 3">
                  <h3>Night Strider</h3>
                    <p>Reflective shoes for  <br>late-night runs.</p>
                    <div class="price">$112</div>
                    <button onclick="addToCart()">Add to Cart</button>
                    <span class="wishlist-icon" onclick="addToWishlist(3, 'Night Strider', 'pic3.png', 69.99)">❤️</span>
                </div>
              <div class="product-cardd">
                  <img src="pic4.png" alt="Product 4"><br><br><br>
                  <h3>Cloud Cruiser</h3>
                    <p>Soft, cushioned sneakers <br> for smooth walks.</p>
                    <div class="price">$79</div>
                    <button onclick="addToCart()">Add to Cart</button>
                    <span class="wishlist-icon" onclick="addToWishlist(4, 'Cloud Cruiser', 'pic4.png', 79.99)">❤️</span>
                </div>
              <div class="product-cardd">
                  <img src="pic5.png" alt="Product 5">
                  <h3>Fast Lane</h3>
                    <p>Speed-enhancing shoes <br> for runners.</p>
                    <div class="price">$89</div>
                    <button onclick="addToCart()">Add to Cart</button>
                    <span class="wishlist-icon" onclick="addToWishlist(5, 'Fast Lane', 'pic5.png', 89.99)">❤️</span>
                </div>
              <div class="product-cardd">
                  <img src="pic6.png" alt="Product 6">
                  <h3>Eco Trail</h3>
                    <p>Eco-friendly shoes for <br> green adventures.</p>
                    <div class="price">$99</div>
                    <button onclick="addToCart()">Add to Cart</button>
                    <span class="wishlist-icon" onclick="addToWishlist(6, 'Eco Trail', 'pic6.png', 99.99)">❤️</span>
                </div>
              <div class="product-cardd">
                  <img src="pic7.png" alt="Product 7">
                  <h3>Blaze Runner</h3>
                    <p>High-performance shoes <br>for fast runs.</p>
                    <div class="price">$109.99</div>
                    <button onclick="addToCart()">Add to Cart</button>
                    <span class="wishlist-icon" onclick="addToWishlist(7, 'Blaze Runner', 'pic7.png', 109.99)">❤️</span>
                </div>
              <div class="product-cardd">
                  <img src="pic8.png" alt="Product 8">
                  <h3>Air Glide</h3>
                    <p>Ultra-light shoes for <br> effortless movement.</p>
                    <div class="price">$119.99</div>
                    <button onclick="addToCart()">Add to Cart</button>
                    <span class="wishlist-icon" onclick="addToWishlist(8, 'Air Glide', 'pic8.png', 119.99)">❤️</span>
                </div>
          </div>
        </div>
        <div class="contact">
          <div class="contact1">
              <h4><b>For Any Inconvenience</b></h4>
              <ul>
                  <li><b><i class="fa fa-phone" style="font-size:25px"></i>&nbsp;<a href="tel:97793 – 26640" style="color:black;"> +91-97793-26640</a>&nbsp;,&nbsp;<i class="fa fa-phone" style="font-size:25px"></i>&nbsp;<a href="tel:97800-53009" style="color:black;"> +91-97800-53009</a></b></li>
                  <li><b><i class="fa fa-phone" style="font-size:25px"></i>&nbsp;<a href="tel:0172 – 2217355" style="color:black;">0172 – 2217355</a></b></li>
                  </ul>
                <a href="contactus.php">  <button align="center" id="hovv" >Contact Us </button></a>
          </div>
          <div class="contact2">
              <h6><b>Order Details</b></h6>
              <button align="center" id="hovv">Track Your Order</button>
          </div>
      </div>
      <div class="map">
        <div class="map1">
            <h4>Our Store</h4>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3422.545943390135!2d75.80581822558801!3d30.92731347449105!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391a83ffcaf665dd%3A0x44ecd83b0dcba6fd!2sNew%20Maya%20Nagar%2C%20Durga%20Puri%2C%20Haibowal%20Kalan%2C%20Ludhiana%2C%20Punjab%20141001!5e0!3m2!1sen!2sin!4v1725375401452!5m2!1sen!2sin

            " width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
        <div class="form">
            <form id="callbackForm">>
                <h4>Request a Callback</h4>
                <center>
                <input class="its" type="text" id="firstName" placeholder="FIRST NAME*" required>
                <input class="its" type="text" id="lastName" placeholder="LAST NAME*" required><br>
                <input class="its" type="email"  id="email" placeholder="your email" required>
                <input  class="its"type="number" id="phone" placeholder="Phone No."required><br>
                <input class="its" type="text" id="orderNumber" placeholder="ORDER NUMBER*" required>
                <input class="its" type="date" id="orderDate" placeholder="ORDER DATE" required><br>
                <textarea class="itts" id="address" type="Postal Address" cols="70" rows="6" placeholder="ADDRESS"></textarea>
                <button type="submit" id="hovv">SEND</button>
            </center>
            </form>
        </div>
    </div>
    <div class="footer">
      <div class="foot1">
          <h4>About us</h4>
          <p>StepInStyle aim to bring its customers the choicest pair of exclusive fashionable shoes. You will love our value-for-money shoe prices 
            that will make Metro shoes your go-to for stylish footwear for all occasions. </p>
      </div>
      <div class="foot2">
          <h4>Quick links</h4>
          <ul>
              <a href="home.php" style="color: white;"><li>Home</li></a>
              <a href="men.php" style="color: white;"><li>Men</li></a>
              <a href="women.php" style="color: rgb(255, 248, 248);"><li>Women</li></a>
              <a href="kids.php" style="color: white;"><li>Kids</li></a>
              <a href="sports.php" style="color: white;"><li>Sports</li></a>
              <li>Brands</li>
          </ul>
      </div>
      <div class="foot3">
          <h4>Need Help</h4>
          <ul>
              <li>Order Status</li>
              <li>Delivery</li>
              <li>Returns</li>
              <li>Shipping Policy</li>
              <li>Return and Cancelation Policy</li>
              <li>Contact Us</li>
          </ul>
      </div>
      <div class="foot4">
          <h4>Our Address</h4>
              <p><i class="fa fa-map-marker" style="font-size:15px"></i>&nbsp;New Maya Nagar,Ludhiana</p>
              <p><i class="fa fa-phone" style="font-size:12px"></i>&nbsp;+91-97793-26640,+91-97800-53009</p>
              <p><i class="fa fa-phone" style="font-size:12px"></i>&nbsp;0172-2217355</p>
              <p><i class="fa fa-envelope" style="font-size:12px"></i>&nbsp;kashishnagpal08@gmail.com</p>
      </div>
  </div>
  <div class="footerr">
  <footer>
      <p>&copy;2024 StepInStyle| All Rights Reserved | Designed by ishcompny</p>
      <i class="fa fa-whatsapp mee" style="font-size:14px;color: white; margin: 0px 10px 10px 570px;"></i>
      <i class="fa fa-facebook mee" style="font-size:14px;color: white;margin: 0px 10px 10px 10px;"></i>
      <i class="fa fa-twitter mee" style="font-size:14px;color: white;margin: 0px 10px 10px 10px;"></i>
      <i class="fa fa-youtube-play mee" style="font-size:14px; color: white; margin: 0px 10px 10px 10px;"></i>
      <i class="fa fa-linkedin mee" style="font-size:14px; color: white;margin: 0px 10px 10px 10px;"></i>
      <i class="fa fa-instagram mee" style="font-size:14px; color: white;margin: 0px 10px 10px 10px;"></i>
  </footer>
</div>
 <!-- Clear session data after displaying -->


<script>
    document.getElementById('callbackForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent form from submitting

        // Get form field values
        const firstName = document.getElementById('firstName').value;
        const lastName = document.getElementById('lastName').value;
        const email = document.getElementById('email').value;
        const phone = document.getElementById('phone').value;
        const orderNumber = document.getElementById('orderNumber').value;
        const orderDate = document.getElementById('orderDate').value;
        const address = document.getElementById('address').value;

        // Display a popup with the form details
        alert(`REQUEST SUBMITTED! Here are your details:
        First Name: ${firstName}
        Last Name: ${lastName}
        Email: ${email}
        Phone No.: ${phone}
        Order Number: ${orderNumber}
        Order Date: ${orderDate}
        Address: ${address}`);
    });
</script>
<script>
let currentIndex = 0;
const products = document.querySelectorAll('.product-card');
const totalProducts = products.length;
const slider = document.getElementById('slider');

document.getElementById('next').addEventListener('click', () => {
    if (currentIndex < totalProducts - 1) {
        currentIndex++;
        updateSlider();
    }
});

document.getElementById('prev').addEventListener('click', () => {
    if (currentIndex > 0) {
        currentIndex--;
        updateSlider();
    }
});

function updateSlider() {
    const slideWidth = products[0].offsetWidth;
    slider.style.transform = `translateX(-${currentIndex * slideWidth}px)`;
}

document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', function() {
        const productName = this.parentElement.querySelector('h3').textContent;
        alert(`${productName} has been added to your cart!`);
        // Here you would add the product to the cart in a real application
    });
});

function addToWishlist(product) {
    alert(`${product} has been added to your wishlist!`);
    // Here you would implement the logic to handle the wishlist in a real application
}

function addToWishlist(productId, productName, productImage, productPrice) {
    // Create an AJAX request to add item to wishlist
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "add_to_wishlist.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            alert("Item added to wishlist!");
        }
    };
    xhr.send(`product_id=${productId}&product_name=${productName}&product_image=${productImage}&product_price=${productPrice}`);
}

</script>
</body>
</html>
