// This is where you can add dynamic behavior with JavaScript
// For example, adding items to the cart, filtering products, etc.

document.addEventListener('DOMContentLoaded', () => {
    const buttons = document.querySelectorAll('.button');

    buttons.forEach(button => {
        button.addEventListener('click', () => {
            alert('Button clicked!');
        });
    });
});
