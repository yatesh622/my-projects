<?php
session_start();
require 'db_connection.php'; // include your database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Assuming the user is logged in and we have a user_id stored in session
    $userId = $_SESSION['user_id'];
    $productId = $_POST['product_id'];
    $productName = $_POST['product_name'];
    $productImage = $_POST['product_image'];
    $productPrice = $_POST['product_price'];

    // Insert into wishlist table
    $sql = "INSERT INTO wishlist (user_id, product_id, product_name, product_image, product_price) 
            VALUES ('$userId', '$productId', '$productName', '$productImage', '$productPrice')";
    if (mysqli_query($conn, $sql)) {
        echo "Wishlist item added!";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
?>
