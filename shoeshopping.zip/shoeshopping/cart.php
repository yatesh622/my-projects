<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StepInStyle</title>
    <link rel="stylesheet" href="profile.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style>
    .wishlist-items {
        display: flex;
    /* flex-wrap: wrap; */
    width: 100%;
    /* margin: 30px; */
    justify-content: center;
    }

    .wishlist-item {
        border: 1px solid #ccc;
        margin: 10px;
        padding: 10px;
        width: 200px;
        text-align: center;
    }

    .wishlist-item img {
        width: 100%;
        height: auto;
    }

    .wishlist-item h3 {
        font-size: 18px;
        margin: 10px 0;
    }

    .wishlist-item p {
        font-size: 16px;
        margin: 5px 0;
    }

    .wishlist-item button {
        background-color: #f44336;
        color: white;
        border: none;
        padding: 10px;
        cursor: pointer;
        margin-top: 10px;
    }

    .wishlist-item button:hover {
        background-color: #d32f2f;
    }

</style>
<body>

    <div class="main">
        <div class="upper">
            <div class="name">
                <p>Welcome To StepInStyle</p>
            </div>
            <div class="dis">
                <marquee behavior="scroll" direction="left" onmouseover="stop()" onmouseout="start()">
                    <p>Get 5% Extra Discount On Prepaid Orders</p>
                </marquee>
            </div>
        </div>
        <div class="logo">
            <img src="Capture.png" alt="">
        </div>
        <div class="option">
            <ul>
                <span id="frst"><a href="men.php" style="color: black;"><li>Men</li></span>
                <span id="lines"><a href="women.php" style="color: black;"><li>Women</li></span>
                <span id="lines"><a href="kids.php" style="color: black;"><li>Kids</li></span>
                <span id="lines"><li>Brands</li></span>
                <span id="lines"><a href="sports.php" style="color: black;"><li>Sports</li></span>
                <span id="lines"><li>New</li></span>
                
            </ul>
        </div>

        <div class="srch">
            <div class="search-container">
                <input type="text" class="search-input" placeholder="Search..." aria-label="Search">
                <button class="search-button" aria-label="Perform search">
                    <svg class="search-icon" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#808080" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="11" cy="11" r="8"></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                </button>
            </div>

            <div class="home" id="hove">
                <a href="home.php" style="color: black;">
                    <i class="fa fa-home" style="font-size:30px; padding: 18px 10px 0px 22px;"></i>
                </a>
            </div>

            <div class="heart" id="hove">
                <i class="fa fa-heart" style="font-size:29px; padding: 18px 10px 0px 22px;"></i>
            </div>

            <div class="cart" id="hove">
                <i class="fa fa-shopping-cart" style="font-size:30px; padding: 18px 10px 0px 22px;"></i>
            </div>

        </div>
    </div>
    <h1 align=center>Your Cart</h1>
    <?php
session_start();
include 'db_connection.php';

$user_id = $_SESSION['user_id'];
$query = "SELECT products.name, cart.quantity FROM cart JOIN products ON cart.product_id = products.id WHERE cart.user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();


while ($row = $result->fetch_assoc()) {
    echo "<p>{$row['name']} - Quantity: {$row['quantity']}</p>";
}
?>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $('#add-to-cart').click(function() {
            var productId = $(this).data('product-id');

            $.ajax({
                url: 'add_to_cart.php',
                type: 'POST',
                data: { product_id: productId },
                success: function(response) {
                    alert(response); // Display response as alert or handle UI changes
                }
            });
        });
    });
</script>



</body>
</html>