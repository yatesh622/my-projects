<?php
// Database connection
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = "";     // Replace with your MySQL password
$dbname = "worldwide_immigration";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $mobilenumber = $_POST['mobilenumber'];
    $password = $_POST['PASSWORD'];
    $confirmPassword = $_POST['PASSWORD_CONFIRM'];

    // Check if password and confirm password match
    if ($password != $confirmPassword) {
        echo "Passwords do not match!";
    } else {
        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO users (email, mobilenumber, password) VALUES (?, ?, ?)");
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);  // Hashing the password
        $stmt->bind_param("sss", $email, $mobilenumber, $hashedPassword);

        // Execute the statement
        if ($stmt->execute()) {
            echo "Sign-up successful!";
            header("Location: signin.php");
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Sign In | Worldwide</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="signup.css">
</head>
<body>
    <div class="header1">
        <img src="logo.png" alt="">
    </div>

    <div class="signin">
        <div class="image">
            <img src="image.png" alt="">
        </div>
        <div class="form">
            <h1>Sign Up</h1>
            <form action="signup.php" method="POST">
                <input class="name" type="email" name="email" placeholder="Enter Email*" required>  <br>
                <input class="name" type="number" name="mobilenumber" placeholder="Mobile Number*" required>  <br>
                <input class="name" type="password" name="PASSWORD" placeholder="Create Password" required>
                <input class="name" type="password" name="PASSWORD_CONFIRM" placeholder="Confirm Password" required>
                <button class="but" type="submit">SIGN UP</button>
            </form>

            <a href="signin.php"><p id="hover">Already have an account? Sign In</p></a>
        </div>
    </div>
    

   

    <footer class="footer">
        <p>Copyright © 2024 Worldwide Immigration All rights reserved.</p>
        <div class="ficon">
            <i class="fa fa-whatsapp yes" style="font-size:22px"></i>
            <i class="fa fa-facebook-f yes" style="font-size:22px"></i>
            <i class="fa fa-twitter yes" style="font-size:22px"></i>
            <i class="fa fa-youtube-play yes" style="font-size:22px"></i>
            <i class="fa fa-linkedin yes" style="font-size:22px"></i>
            <i class="fa fa-instagram yes" style="font-size:22px"></i>
            
        </div>
    </footer>
</body>
</html>