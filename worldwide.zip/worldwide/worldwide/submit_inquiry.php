<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "worldwide_immigration";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_name = $_POST['studentname'];
    $email = $_POST['email'];
    $mobile_number = $_POST['mobilenumber'];
    $country = $_POST['country'];
    $question = $_POST['question'];

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO inquiries (student_name, email, mobile_number, country, question) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $student_name, $email, $mobile_number, $country, $question);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Your message has been sent successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }
    
    $stmt->close();
}
$conn->close();
?>
