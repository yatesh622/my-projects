<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = "";     // Replace with your MySQL password
$dbname = "worldwide_immigration";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare statement to get user by email
    $stmt = $conn->prepare("SELECT id, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    
    // Check if user exists
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($userId, $hashedPassword);
        $stmt->fetch();

        // Verify the password
        if (password_verify($password, $hashedPassword)) {
            // Store user information in session
            $_SESSION['user_id'] = $userId;
            echo "Login successful!";
            // Redirect to worldwide.html after successful login
            header("Location: worldwide.html");
            exit();
        } else {
            echo "Invalid email or password.";
        }
    } else {
        echo "No user found with this email.";
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Sign In | Worldwide</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="signin.css">
</head>
<body>
    <div class="header1">
        <img src="logo.png" alt="">
    </div>

    <div class="signin">
        <div class="image">
            <img src="image.png" alt="">
        </div>
        <div class="form">
            <h1>Sign In</h1>
            <form action="signin.php" method="POST">
                <input class="name" type="email" name="email" placeholder="Email*" required>  <br>
                <input class="name" type="password" name="password" placeholder="Password*" required>
                <button class="but" type="submit">SIGN IN</button>
            </form>

            <a href="signup.php"><p id="hover">New to Worldwide Immigration? Create an account</p></a>
        </div>
    </div>
    

   

    <footer class="footer">
        <p>Copyright © 2024 Worldwide Immigration All rights reserved.</p>
        <div class="ficon">
            <i class="fa fa-whatsapp yes" style="font-size:22px"></i>
            <i class="fa fa-facebook-f yes" style="font-size:22px"></i>
            <i class="fa fa-twitter yes" style="font-size:22px"></i>
            <i class="fa fa-youtube-play yes" style="font-size:22px"></i>
            <i class="fa fa-linkedin yes" style="font-size:22px"></i>
            <i class="fa fa-instagram yes" style="font-size:22px"></i>
            
        </div>
    </footer>
</body>
</html>